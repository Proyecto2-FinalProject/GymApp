﻿const handleEditEquipment = (event) => {
    event.preventDefault();

    const equipment = {
        equipmentId: $("#equipmentId").val(),
        name: $("#name").val(),
        description: $("#description").val(),
        quantity: $("#quantity").val(),
        status: $("#status").val()
    };

    const apiUrl = API_URL_BASE + "/api/Equipments/EditEquipment";

    $.ajax({
        url: apiUrl,
        method: "POST",
        hasContent: true,
        data: JSON.stringify(equipment),
        contentType: "application/json;charset=utf-8",
        dataType: "json",
    }).done((result) => {
        console.log(result);
        Swal.fire({
            title: "Equipment Update",
            text: "Equipment Updated Successfully",
            icon: "success",
        }).then(() => {
            window.location.href = '/Equipment/EquipmentList';
        });
    }).fail((jqXHR, textStatus, errorThrown) => {
        console.error(textStatus, errorThrown);
        Swal.fire({
            title: "Error",
            text: "Failed to update equipment. Please try again.",
            icon: "error",
        });
    });
};

$(document).ready(() => {
    $("#editEquipmentForm").on("submit", handleEditEquipment);
});
