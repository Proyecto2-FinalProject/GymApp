﻿const fetchEquipmentList = () => {
    const apiUrl = API_URL_BASE + "/api/Equipments/GetAllEquipment";

    $.ajax({
        url: apiUrl,
        method: "GET",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
    }).done((result) => {
        const tableBody = $("#equipmentTable tbody");
        tableBody.empty();

        result.forEach(equipment => {
            const row = `
                <tr>
                    <td>${equipment.name}</td>
                    <td>${equipment.description}</td>
                    <td>${equipment.quantity}</td>
                    <td>${equipment.status}</td>
                    <td><button onclick="editEquipment(${equipment.equipmentId})">Edit</button></td>
                    <td><button onclick="deleteEquipment(${equipment.equipmentId})">Delete</button></td>
                </tr>
            `;
            tableBody.append(row);
        });
    }).fail((jqXHR, textStatus, errorThrown) => {
        console.error(textStatus, errorThrown);
    });
};

const editEquipment = (id) => {
    window.location.href = `/Equipment/EditEquipment/${id}`;
};

const deleteEquipment = (id) => {
    const apiUrl = API_URL_BASE + `/api/Equipments/DeleteEquipment/${id}`;

    $.ajax({
        url: apiUrl,
        method: "DELETE",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
    }).done((result) => {
        Swal.fire({
            title: "Equipment Deletion",
            text: "Equipment Deleted Successfully",
            icon: "success",
        }).then(() => {
            fetchEquipmentList();
        });
    }).fail((jqXHR, textStatus, errorThrown) => {
        console.error(textStatus, errorThrown);
        Swal.fire({
            title: "Error",
            text: "Failed to delete equipment. Please try again.",
            icon: "error",
        });
    });
};

$(document).ready(() => {
    fetchEquipmentList();
});
