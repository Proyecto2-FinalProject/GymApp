﻿const handleCreateEquipment = (event) => {
    event.preventDefault();

    const equipment = {
        name: $("#name").val(),
        description: $("#description").val(),
        quantity: $("#quantity").val(),
        status: $("#status").val()
    };

    const apiUrl = API_URL_BASE + "/api/Equipments/CreateEquipment";

    $.ajax({
        url: apiUrl,
        method: "POST",
        hasContent: true,
        data: JSON.stringify(equipment),
        contentType: "application/json;charset=utf-8",
        dataType: "json",
    }).done((result) => {
        console.log(result);
        Swal.fire({
            title: "Equipment Creation",
            text: "Equipment Created Successfully",
            icon: "success",
        }).then(() => {
            window.location.href = '/Equipment/EquipmentList';
        });
    }).fail((jqXHR, textStatus, errorThrown) => {
        console.error(textStatus, errorThrown);
        Swal.fire({
            title: "Error",
            text: "Failed to create equipment. Please try again.",
            icon: "error",
        });
    });
};

$(document).ready(() => {
    $("#createEquipmentForm").on("submit", handleCreateEquipment);
});
