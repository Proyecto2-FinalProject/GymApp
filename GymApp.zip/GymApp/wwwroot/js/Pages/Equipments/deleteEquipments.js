﻿const handleDeleteEquipment = (event) => {
    event.preventDefault();

    const equipmentId = $("#equipmentId").val();
    const apiUrl = API_URL_BASE + `/api/Equipments/DeleteEquipment/${equipmentId}`;

    $.ajax({
        url: apiUrl,
        method: "DELETE",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
    }).done((result) => {
        Swal.fire({
            title: "Equipment Deletion",
            text: "Equipment Deleted Successfully",
            icon: "success",
        }).then(() => {
            window.location.href = '/Equipment/EquipmentList';
        });
    }).fail((jqXHR, textStatus, errorThrown) => {
        console.error(textStatus, errorThrown);
        Swal.fire({
            title: "Error",
            text: "Failed to delete equipment. Please try again.",
            icon: "error",
        });
    });
};

$(document).ready(() => {
    $("#deleteEquipmentForm").on("submit", handleDeleteEquipment);
});
